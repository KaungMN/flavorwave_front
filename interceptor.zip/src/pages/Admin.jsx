import ChartTest from "../components/admin/Chart";
import Container from "react-bootstrap/Container";

function Admin() {
  return (
    <Container>
      <h1>Admin</h1>
      <ChartTest />
    </Container>
  );
}

export default Admin;
