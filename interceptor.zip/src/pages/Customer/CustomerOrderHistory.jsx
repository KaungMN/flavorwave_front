import TableComponent from "../../components/customers/table/Table";

function CustomerOrderHistory() {
  return (
    <div>
      <h1>Your Orders</h1>
      <TableComponent />
    </div>
  );
}

export default CustomerOrderHistory;
