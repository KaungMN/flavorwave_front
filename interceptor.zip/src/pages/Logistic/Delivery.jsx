import ApproveDeliveryCard from "../../components/logistic/ApproveCard";

function Delivery() {
  return (
    <div className="mx-auto">
      <h1>delivery</h1>
      <ApproveDeliveryCard />
    </div>
  );
}

export default Delivery;
