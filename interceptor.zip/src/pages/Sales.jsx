import TableComponent from "../components/sales/table/Table.jsx";
function sales() {
  return (
    <div>
      sales
      <TableComponent />
    </div>
  );
}

export default sales;
