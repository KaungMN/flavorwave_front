import TableComponent from "../components/warehouse/table/Table";  
function warehouse() {
  return <div>
    <h1>Ware House</h1>
    <TableComponent />
  </div>
}

export default warehouse;
